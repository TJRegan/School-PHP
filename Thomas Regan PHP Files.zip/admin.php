<?php
session_start();

if ($_SESSION["checkuser"] === "login")
	
	{
		echo "You are now logged in. <br><br> To return home, click the link below<br>";

	} 
?>


<a href="index.html">Login</a>